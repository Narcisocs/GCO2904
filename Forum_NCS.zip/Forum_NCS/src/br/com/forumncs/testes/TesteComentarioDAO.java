package br.com.forumncs.testes;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

import br.com.forumncs.interfaces.ComentarioDAO;
import br.com.forumncs.model.Comentario;
import br.com.forumncs.model.ComentarioDAOImpl;
import br.com.forumncs.services.ServicosComentarios;

public class TesteComentarioDAO {

	JdbcDatabaseTester jdt;
	ComentarioDAO comentarioDAO = new ComentarioDAOImpl();
	ServicosComentarios servicos = new ServicosComentarios(comentarioDAO);
	
	@Before
	public void setUp() throws Exception {
		jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "root");
		
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet dataSetDelete = loader.load("/clearDB.xml");
		jdt.setDataSet(dataSetDelete);
		jdt.setSetUpOperation(DatabaseOperation.DELETE_ALL);
		jdt.onSetup();
		
		IDataSet dataSetInsertsTopico = loader.load("/inicio.xml");
	  	jdt.setDataSet(dataSetInsertsTopico);
	  	jdt.setSetUpOperation(DatabaseOperation.CLEAN_INSERT);
	  	jdt.onSetup();
		
		/*FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/inicio.xml"));
		jdt.onSetup();*/
	}	
	
	@Test
	public void testLista() {
		List<Comentario> lista = servicos.getComentarios(1);
		assertEquals("joao", lista.get(0).getLogin());
		assertEquals("esse forum � muito bom", lista.get(0).getComentario());
		assertEquals("de boa no forum", lista.get(1).getComentario());
		
		List<Comentario> lista2 = servicos.getComentarios(2);
		assertEquals("maria", lista2.get(0).getLogin());
		assertEquals("forum muito interessante", lista2.get(0).getComentario());
	}
	
	@Test
	public void testInserirComentario() throws SQLException, Exception {
		servicos.InserirComentario("forum mais legal da web", "jose", 3);
		
		IDataSet currentDataSet = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataSet.getTable("COMENTARIO");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataSet = loader.load("/insereDepois.xml");
		ITable expectedTable = expectedDataSet.getTable("COMENTARIO");
		Assertion.assertEquals(expectedTable, currentTable);
	}

}
