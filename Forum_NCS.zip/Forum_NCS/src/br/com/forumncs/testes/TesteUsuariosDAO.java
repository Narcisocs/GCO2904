package br.com.forumncs.testes;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

import br.com.forumncs.interfaces.UsuarioDAO;
import br.com.forumncs.model.Usuario;
import br.com.forumncs.model.UsuarioDAOImpl;
import br.com.forumncs.services.ServicosUsuarios;

public class TesteUsuariosDAO {

	JdbcDatabaseTester jdt;
	UsuarioDAO userDAO = new UsuarioDAOImpl();
	ServicosUsuarios servicos = new ServicosUsuarios(userDAO);
	
	@Before
	public void setUp() throws Exception {
		jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "root");
		
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet dataSetDelete = loader.load("/clearDB.xml");
		jdt.setDataSet(dataSetDelete);
		jdt.setSetUpOperation(DatabaseOperation.DELETE_ALL);
		jdt.onSetup();
	  
	  	IDataSet dataSetInserts = loader.load("/inicio.xml");
	  	jdt.setDataSet(dataSetInserts);
	  	jdt.setSetUpOperation(DatabaseOperation.CLEAN_INSERT);
	  	jdt.onSetup();
		
		/*FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/inicio.xml"));
		jdt.onSetup();*/
	}

	@Test
	public void ranking() {
		List<Usuario> ranking = servicos.ranking();
		assertEquals(4, ranking.size());
		assertEquals("joao", ranking.get(0).getLogin());
		assertEquals(11, ranking.get(2).getPontos());
	}
	
	@Test
	public void recuperaRegistro() {
		Usuario usuario = servicos.recuperar("maria");
		assertEquals("maria@email.com", usuario.getEmail());
		assertEquals(12, usuario.getPontos());
	}

	@Test
	public void insereRegistro() throws Exception {
		Usuario u = new Usuario();
		u.setLogin("fulano");
		u.setNome("fulano");
		u.setEmail("fulano@email.com");
		u.setSenha("1234");
		u.setPontos(5);
		
		servicos.inserir(u);
		
		IDataSet currentDataSet = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataSet.getTable("USUARIO");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataSet = loader.load("/insereDepois.xml");
		ITable expectedTable = expectedDataSet.getTable("USUARIO");
		Assertion.assertEquals(expectedTable, currentTable);
	}
	
	@Test
	public void updateDePontos() throws Exception {
		
		servicos.adicionarPontos("maria", 10);
		
		IDataSet currentDataSet = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataSet.getTable("USUARIO");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataSet = loader.load("/updateDepois.xml");
		ITable expectedTable = expectedDataSet.getTable("USUARIO");
		Assertion.assertEquals(expectedTable, currentTable);
	}
	
	@Test
	public void autenticar() throws Exception {
		
		String nomeRecuperado = servicos.autenticar("maria eduarda", "98756");
		assertEquals("duda", nomeRecuperado);
	}
}
