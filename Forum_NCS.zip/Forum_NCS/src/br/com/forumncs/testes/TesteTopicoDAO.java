package br.com.forumncs.testes;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.management.RuntimeErrorException;

import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.operation.DatabaseOperation;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

import br.com.forumncs.interfaces.TopicoDAO;
import br.com.forumncs.model.Topico;
import br.com.forumncs.model.TopicoDAOImpl;
import br.com.forumncs.model.Usuario;
import br.com.forumncs.services.ServicosTopicos;
import br.com.forumncs.services.ServicosUsuarios;

public class TesteTopicoDAO {

	JdbcDatabaseTester jdt;
	TopicoDAO topicoDAO = new TopicoDAOImpl();
	ServicosTopicos servicos = new ServicosTopicos(topicoDAO);
	
	@Before
	public void setUp() throws Exception {
		jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "root");
		
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet dataSetDelete = loader.load("/clearDB.xml");
		jdt.setDataSet(dataSetDelete);
		jdt.setSetUpOperation(DatabaseOperation.DELETE_ALL);
		jdt.onSetup();
		
		IDataSet dataSetInsertsTopico = loader.load("/inicio.xml");
	  	jdt.setDataSet(dataSetInsertsTopico);
	  	jdt.setSetUpOperation(DatabaseOperation.CLEAN_INSERT);
	  	jdt.onSetup();
		
		/*FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/inicio.xml"));
		jdt.onSetup();*/
	}

	@Test
	public void testLista() {
		List<Topico> lista = servicos.getTopicos();
		assertEquals(3, lista.size());
		assertEquals("joao", lista.get(0).getLogin());
		assertEquals("adicionando comentarios", lista.get(2).getTitulo());
	}
	
	/*@Test
	public void insereRegistro() throws Exception {
		servicos.InserirTopico("teste", "teste de conteudo", "joao");
		
		IDataSet currentDataSet = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataSet.getTable("TOPICO");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataSet = loader.load("/insereDepois.xml");
		ITable expectedTable = expectedDataSet.getTable("TOPICO");
		Assertion.assertEquals(expectedTable, currentTable);
	}*/
	
	@Test
	public void testTopico() {
		Topico topico = servicos.exibirTopico(1);
		assertEquals("joao", topico.getLogin());
		assertEquals("Testando o forum", topico.getTitulo());
		assertEquals("navegando pelo forum", topico.getConteudo());
	}
}
