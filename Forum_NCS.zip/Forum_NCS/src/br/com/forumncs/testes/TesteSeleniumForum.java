package br.com.forumncs.testes;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class TesteSeleniumForum {

	  private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();

	  @Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
	    driver = new ChromeDriver();
	    baseUrl = "http://localhost:8080/";
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	  }

	  @Test
	  public void testInserindoComentario() throws Exception {
	    driver.get(baseUrl + "/Forum_NCS/pages/login.jsp");
	    driver.findElement(By.name("login")).clear();
	    driver.findElement(By.name("login")).sendKeys("narciso");
	    driver.findElement(By.name("senha")).clear();
	    driver.findElement(By.name("senha")).sendKeys("1234");
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    driver.findElement(By.linkText("teste")).click();
	    driver.findElement(By.name("comentario")).clear();
	    driver.findElement(By.name("comentario")).sendKeys("Teste de comentario novo");
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    assertEquals("Teste de comentario novo", driver.findElement(By.xpath("//div[6]")).getText());
	  }
	  
	  @Test
	  public void testCadastrandoUsuarioEVendoRanking() throws Exception {
	    driver.get(baseUrl + "/Forum_NCS/pages/login.jsp");
	    driver.findElement(By.linkText("Cadastrar-se")).click();
	    driver.findElement(By.name("nomeCadastro")).clear();
	    driver.findElement(By.name("nomeCadastro")).sendKeys("david");
	    driver.findElement(By.name("emailCadastro")).clear();
	    driver.findElement(By.name("emailCadastro")).sendKeys("david@email.com");
	    driver.findElement(By.name("loginCadastro")).clear();
	    driver.findElement(By.name("loginCadastro")).sendKeys("david");
	    driver.findElement(By.name("senhaCadastro")).clear();
	    driver.findElement(By.name("senhaCadastro")).sendKeys("4321");
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    driver.findElement(By.name("login")).clear();
	    driver.findElement(By.name("login")).sendKeys("david");
	    driver.findElement(By.name("senha")).clear();
	    driver.findElement(By.name("senha")).sendKeys("4321");
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    driver.findElement(By.linkText("Ranking")).click();
	    assertEquals("david", driver.findElement(By.xpath("//tr[8]/td")).getText());
	    driver.findElement(By.linkText("Voltar aos Topicos")).click();
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	  }
	  
	  @Test
	  public void testInserindoTopico() throws Exception {
	    driver.get(baseUrl + "/Forum_NCS/pages/login.jsp");
	    driver.findElement(By.name("login")).clear();
	    driver.findElement(By.name("login")).sendKeys("david");
	    driver.findElement(By.name("senha")).clear();
	    driver.findElement(By.name("senha")).sendKeys("4321");
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    driver.findElement(By.linkText("Inserir Topico")).click();
	    driver.findElement(By.name("tituloTopico")).clear();
	    driver.findElement(By.name("tituloTopico")).sendKeys("Teste com usuario David");
	    driver.findElement(By.name("conteudoTopico")).clear();
	    driver.findElement(By.name("conteudoTopico")).sendKeys("teste de conteudo com usuario david");
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    assertEquals("Teste com usuario David", driver.findElement(By.linkText("Teste com usuario David")).getText());
	    driver.findElement(By.linkText("Ranking")).click();
	    driver.findElement(By.linkText("Voltar aos Topicos")).click();
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	  }

	  @After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }

	  private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  private boolean isAlertPresent() {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	  private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }
}
