package br.com.forumncs.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.forumncs.exceptions.LoginException;
import br.com.forumncs.interfaces.UsuarioDAO;

//CLASSE DA SEMANA 3
public class UsuarioDAOImpl implements UsuarioDAO{

	static{
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void inserir(Usuario u) {
		// TODO Auto-generated method stub
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera","postgres","root") ){
			
			String sqlInsere = "INSERT INTO usuario(login, email, nome, senha, pontos) VALUES (?, ?, ?, ?, ?);";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			statement.setString(1, u.getLogin());
			statement.setString(2, u.getEmail());
			statement.setString(3, u.getNome());
			statement.setString(4, u.getSenha());
			statement.setInt(5, u.getPontos());	
			statement.executeUpdate();
			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
	}

	@Override
	public Usuario recuperar(String login) {
		Usuario usuario = new Usuario();
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlRecupera = "SELECT * FROM usuario WHERE login = ?;";
			PreparedStatement statement = conn.prepareStatement(sqlRecupera);
			statement.setString(1, login);
			ResultSet rs = statement.executeQuery();
			
			if (rs.next()){
				usuario.setLogin(rs.getString("login"));
				usuario.setNome(rs.getString("login"));
				usuario.setEmail(rs.getString("email"));
				usuario.setSenha(rs.getString("senha"));
				usuario.setPontos(rs.getInt("pontos"));
			}
			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
		
		return usuario;
	}

	@Override
	public void adicionarPontos(String login, int pontos) {
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "UPDATE usuario SET pontos = pontos + ? WHERE login = ?;";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			statement.setInt(1, pontos);
			statement.setString(2, login);
			statement.executeUpdate();
			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
	}

	@Override
	public List<Usuario> getRanking() {
		List<Usuario> ranking = new ArrayList<>();
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "SELECT * FROM usuario ORDER BY pontos DESC;";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()){
				Usuario u = new Usuario();
				u.setLogin(rs.getString("login"));
				u.setNome(rs.getString("login"));
				u.setEmail(rs.getString("email"));
				u.setSenha(rs.getString("senha"));
				u.setPontos(rs.getInt("pontos"));
				
				ranking.add(u);
			}
			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
		return ranking;
	}
	
	@Override
	public String autenticar(String login, String senha) throws LoginException, SQLException {
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera","postgres","root") ){
			PreparedStatement stm = conn.prepareStatement("Select nome from usuario where login = ? and senha = ?;");
			stm.setString(1, login);
			stm.setString(2, senha);
			
			ResultSet rs = stm.executeQuery();
			
			if(rs.next()){
				return rs.getString("nome");
			}else {
				throw new LoginException();
			}
		}
	}
}
