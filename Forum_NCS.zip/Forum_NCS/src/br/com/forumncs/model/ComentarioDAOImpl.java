package br.com.forumncs.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.forumncs.interfaces.ComentarioDAO;

public class ComentarioDAOImpl implements ComentarioDAO{

	@Override
	public List<Comentario> getComentarios(Integer idTopico) {
		List<Comentario> lista = new ArrayList<>();
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "SELECT * FROM COMENTARIO where id_topico = ?;";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			statement.setInt(1, idTopico);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()){
				Comentario c = new Comentario();
				c.setTopico(rs.getInt("ID_TOPICO"));
				c.setComentario(rs.getString("comentario"));
				c.setLogin(rs.getString("login"));
				
				lista.add(c);
			}
			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
		
		return lista;
	}

	@Override
	public void InserirComentario(String comentario, String login, Integer idTopico) {
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "Insert into COMENTARIO(login, comentario, id_topico) values (?, ?, ?);";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			statement.setString(1, login);
			statement.setString(2, comentario);
			statement.setInt(3, idTopico);
			statement.executeUpdate();
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
	}
}
