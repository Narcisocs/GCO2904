package br.com.forumncs.model;

public class Comentario {
	private String login;
	private String comentario;
	private Integer topico;
	
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public Integer getTopico() {
		return topico;
	}
	public void setTopico(Integer topico) {
		this.topico = topico;
	}
}
