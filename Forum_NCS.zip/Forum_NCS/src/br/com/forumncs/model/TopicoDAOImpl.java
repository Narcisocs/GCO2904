package br.com.forumncs.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.forumncs.interfaces.TopicoDAO;

public class TopicoDAOImpl implements TopicoDAO {

	@Override
	public List<Topico> getLista() {
		List<Topico> lista = new ArrayList<>();
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "SELECT * FROM Topico;";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			ResultSet rs = statement.executeQuery();
			
			while (rs.next()){
				Topico t = new Topico();
				t.setId(rs.getInt("ID_TOPICO"));
				t.setTitulo(rs.getString("titulo"));
				t.setConteudo(rs.getString("conteudo"));
				t.setLogin(rs.getString("login"));
				
				lista.add(t);
			}
			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
		
		return lista;
	}

	@Override
	public Topico getTopico(int id) {
		Topico topico = new Topico();
		
		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "SELECT * FROM Topico where ID_TOPICO = ?;";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			
			if (rs.next()){
				topico.setId(rs.getInt("ID_TOPICO"));
				topico.setTitulo(rs.getString("titulo"));
				topico.setConteudo(rs.getString("conteudo"));
				topico.setLogin(rs.getString("login"));
			}
		}			
		catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
		
		return topico;
	}

	@Override
	public void InserirTopico(String titulo, String conteudo, String login) {

		try(Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "root")){
			
			String sqlInsere = "Insert into Topico(login, titulo, conteudo) values (?, ?, ?);";
			PreparedStatement statement = conn.prepareStatement(sqlInsere);
			statement.setString(1, login);
			statement.setString(2, titulo);
			statement.setString(3, conteudo);
			statement.executeUpdate();			
		}catch (SQLException e) {
			throw new RuntimeException("N�o foi poss�vel conectar ao banco",e);
		}
		
	}
}
