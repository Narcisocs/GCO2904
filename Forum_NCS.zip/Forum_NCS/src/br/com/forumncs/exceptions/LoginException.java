package br.com.forumncs.exceptions;

public class LoginException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5681227052473121273L;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "N�o Existe Usu�rio com esse login e senha";
	}

}
