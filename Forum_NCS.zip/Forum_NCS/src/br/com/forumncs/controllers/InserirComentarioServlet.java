package br.com.forumncs.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.forumncs.interfaces.ComentarioDAO;
import br.com.forumncs.interfaces.TopicoDAO;
import br.com.forumncs.interfaces.UsuarioDAO;
import br.com.forumncs.model.Comentario;
import br.com.forumncs.model.ComentarioDAOImpl;
import br.com.forumncs.model.Topico;
import br.com.forumncs.model.TopicoDAOImpl;
import br.com.forumncs.model.UsuarioDAOImpl;
import br.com.forumncs.services.ServicosComentarios;
import br.com.forumncs.services.ServicosTopicos;
import br.com.forumncs.services.ServicosUsuarios;

/**
 * Servlet implementation class InserirComentario
 */
@WebServlet("/pages/InserirComentario")
public class InserirComentarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InserirComentarioServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String comentario = request.getParameter("comentario");
		String login = request.getParameter("usuario");
		String topico = request.getParameter("id");
		
		ComentarioDAO comentarioDao = new ComentarioDAOImpl();
		ServicosComentarios servicoComentarios = new ServicosComentarios(comentarioDao);
		
		servicoComentarios.InserirComentario(comentario, login, Integer.valueOf(topico));
		
		UsuarioDAO userDao = new UsuarioDAOImpl();
		ServicosUsuarios servicosUsuarios = new ServicosUsuarios(userDao);
		
		servicosUsuarios.adicionarPontos(login, 3);
		
		TopicoDAO topicoDAO = new TopicoDAOImpl();
		ServicosTopicos servicosTopicos = new ServicosTopicos(topicoDAO);
		
		Topico t = servicosTopicos.exibirTopico(Integer.valueOf(topico));
		request.setAttribute("topico", t);
		
		List<Comentario> lista = servicoComentarios.getComentarios(Integer.valueOf(topico));
		request.setAttribute("listaComentarios", lista);
		
		request.getRequestDispatcher("exibirTopico.jsp").forward(request, response);
	}

}
