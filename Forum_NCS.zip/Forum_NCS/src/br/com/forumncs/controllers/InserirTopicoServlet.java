package br.com.forumncs.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.forumncs.interfaces.TopicoDAO;
import br.com.forumncs.interfaces.UsuarioDAO;
import br.com.forumncs.model.TopicoDAOImpl;
import br.com.forumncs.model.UsuarioDAOImpl;
import br.com.forumncs.services.ServicosTopicos;
import br.com.forumncs.services.ServicosUsuarios;

/**
 * Servlet implementation class InserirTopico
 */
@WebServlet("pages/InserirTopico")
public class InserirTopicoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InserirTopicoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String titulo = request.getParameter("tituloTopico");
		String conteudo = request.getParameter("conteudoTopico");
		String login = request.getParameter("usuario");
		
		TopicoDAO topicoDao = new TopicoDAOImpl();
		ServicosTopicos servicosTopico = new ServicosTopicos(topicoDao);
		
		servicosTopico.InserirTopico(titulo, conteudo, login);
		
		UsuarioDAO userDao = new UsuarioDAOImpl();
		ServicosUsuarios servicosUsuarios = new ServicosUsuarios(userDao);
		
		servicosUsuarios.adicionarPontos(login, 10);
		
		request.getRequestDispatcher("topicos.jsp").forward(request, response);
	}

}
