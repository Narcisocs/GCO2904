package br.com.forumncs.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.forumncs.interfaces.ComentarioDAO;
import br.com.forumncs.interfaces.TopicoDAO;
import br.com.forumncs.model.Comentario;
import br.com.forumncs.model.ComentarioDAOImpl;
import br.com.forumncs.model.Topico;
import br.com.forumncs.model.TopicoDAOImpl;
import br.com.forumncs.services.ServicosComentarios;
import br.com.forumncs.services.ServicosTopicos;
/**
 * Servlet implementation class ExibirTopico
 */
@WebServlet("pages/ExibirTopico")
public class ExibirTopicoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExibirTopicoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		
		TopicoDAO topicoDAO = new TopicoDAOImpl();
		ServicosTopicos servicosTopicos = new ServicosTopicos(topicoDAO);
		
		Topico topico = servicosTopicos.exibirTopico(Integer.valueOf(id));
		request.setAttribute("topico", topico);
		
		ComentarioDAO comentario = new ComentarioDAOImpl();
		ServicosComentarios servicosComentarios = new ServicosComentarios(comentario);
		
		List<Comentario> lista = servicosComentarios.getComentarios(Integer.valueOf(id));
		request.setAttribute("listaComentarios", lista);
		
		request.getRequestDispatcher("exibirTopico.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
