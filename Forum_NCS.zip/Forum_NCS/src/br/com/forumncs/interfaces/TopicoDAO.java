package br.com.forumncs.interfaces;

import java.util.List;

import br.com.forumncs.model.Topico;

public interface TopicoDAO {

	public List<Topico> getLista();
	public Topico getTopico(int id);
	public void InserirTopico (String titulo, String conteudo, String login);
}
