package br.com.forumncs.interfaces;

import java.util.List;

import br.com.forumncs.model.Comentario;

public interface ComentarioDAO {
	
	public List<Comentario> getComentarios(Integer idTopico);
	public void InserirComentario(String comentario, String login, Integer idTopico);
}
