package br.com.forumncs.interfaces;

import java.sql.SQLException;
import java.util.List;

import br.com.forumncs.exceptions.LoginException;
import br.com.forumncs.model.Usuario;

//Interface da SEMANA 3
public interface UsuarioDAO {

	//insere um novo usu�rio no banco de dados
   public void inserir(Usuario u);
   
   //recupera o usu�rio pelo seu login
   public Usuario recuperar(String login);
   
   //adiciona os pontos para o usu�rio no banco
   public void adicionarPontos(String login, int pontos);
   
   //retorna a lista de usu�rios ordenada por pontos (maior primeiro)
   public List<Usuario> getRanking();
   
   //Novos m�todos necess�rios
   public String autenticar(String login, String senha) throws LoginException, SQLException;
}
