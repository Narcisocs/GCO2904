package br.com.forumncs.services;

import java.util.List;

import br.com.forumncs.interfaces.TopicoDAO;
import br.com.forumncs.model.Topico;

public class ServicosTopicos {

	private TopicoDAO _topicoDAO;
	
	public ServicosTopicos(TopicoDAO topicoDAO) {
		this._topicoDAO = topicoDAO;
	}
	
	public List<Topico> getTopicos() {
		List<Topico> lista;
		
		lista = _topicoDAO.getLista();
		
		return lista;
	}
	
	public Topico exibirTopico(int id) {
		Topico topico;
		
		topico = _topicoDAO.getTopico(id);
		
		return topico;
	}
	
	public void InserirTopico (String titulo, String conteudo, String login){
		_topicoDAO.InserirTopico(titulo, conteudo, login);
	}
}
