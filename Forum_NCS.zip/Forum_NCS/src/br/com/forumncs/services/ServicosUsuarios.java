package br.com.forumncs.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.forumncs.exceptions.LoginException;
import br.com.forumncs.interfaces.UsuarioDAO;
import br.com.forumncs.model.Usuario;

public class ServicosUsuarios {

	private UsuarioDAO _userDAO;
	
	public ServicosUsuarios(UsuarioDAO userDAO) {
		this._userDAO = userDAO;
	}
	
	public void inserir(Usuario u) {
		// TODO Auto-generated method stub
		_userDAO.inserir(u);
	}

	public Usuario recuperar(String login) {
		Usuario usuario = new Usuario();
		
		usuario = _userDAO.recuperar(login);
		
		return usuario;
	}

	
	public void adicionarPontos(String login, int pontos) {
		_userDAO.adicionarPontos(login, pontos);
	}

	public List<Usuario> ranking() {
		List<Usuario> ranking = new ArrayList<>();
		
		ranking = _userDAO.getRanking();
		
		return ranking;
	}
	
	public String autenticar(String login, String senha) throws LoginException, SQLException {
		return _userDAO.autenticar(login, senha);
	}
}
