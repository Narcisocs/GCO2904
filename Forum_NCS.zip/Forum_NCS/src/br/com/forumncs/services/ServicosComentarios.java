package br.com.forumncs.services;

import java.util.List;

import br.com.forumncs.interfaces.ComentarioDAO;
import br.com.forumncs.model.Comentario;

public class ServicosComentarios {

	private ComentarioDAO _comentarioDAO;
	
	public ServicosComentarios(ComentarioDAO comentarioDAO) {
		this._comentarioDAO = comentarioDAO;
	}
	
	public List<Comentario> getComentarios(Integer idTopico){
		List<Comentario> lista;
		
		lista = _comentarioDAO.getComentarios(idTopico);
		
		return lista;
	}
	
	public void InserirComentario(String comentario, String login, Integer idTopico){
		_comentarioDAO.InserirComentario(comentario, login, idTopico);
	}
}
